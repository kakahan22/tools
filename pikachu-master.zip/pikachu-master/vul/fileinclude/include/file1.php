<?php
$html.=<<<A
<img class=player src="include/kobe.png" />
<p class=nabname>
Kobe Bryant is one of the NBA's best scorer, breakthrough, shooting, free throws, three-pointers he chameleonic, almost no offensive blind area, single-game 81 points of personal record is powerful to prove it.In addition to crazy to points, Bryant's organizational ability is also very outstanding, often served as the first sponsors on offense.Bryant is the best form of defence in the league, one of personal defense is very oppressive.
He is a great NAB player!
</p>
A;
?>