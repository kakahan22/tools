/**
 * @author 鳗驼螺(mandarava)
 * 2016.4
 **/
public class ApkIDE
{
	public String 软件名称="APK改之理";
	public String 软件类型="免费软件";
	public String 软件别名="APK IDE";
	public String 程序开发="鳗驼螺(Mandarava)";
	public String 联系邮箱="mandarava@yeah.net";
	public String 新浪微博="http://weibo.com/apktool";
	public String 官方网站="http://www.popotu.com/";
	public String 版权信息="版权所有(C)2016, 保留部份权利.";
	public String 软件简介="一个可视化的、易用的、快捷的、一体化的APK修改工具.";
	public String 一个提示="按住Ctrl键，右键单击左侧目录或搜索结果中的文件会弹出系统右键菜单";
	public String 更多信息="http://www.popotu.com/apkide.html";
	public String 感谢信息="ApkTool,Dex2jar,JD-GUI,JAD,Skin#,SharpDevelop,GongShell 还有当然是 GOOGLE";
}